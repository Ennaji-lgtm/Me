self.addEventListener("push",e=>{let d={};try{d=e.data.json()}catch(x){}
e.waitUntil(self.registration.showNotification(d.title||"Douae & Mohammed 🌙",{body:d.body||"",icon:"/icon-192.png",badge:"/icon-192.png",tag:"us",renotify:true}))});
self.addEventListener("notificationclick",e=>{e.notification.close();
e.waitUntil(clients.matchAll({type:"window",includeUncontrolled:true}).then(l=>l.length?l[0].focus():clients.openWindow("/")))});

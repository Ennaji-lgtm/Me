import {getStore} from "@netlify/blobs";
import webpush from "web-push";
import {createHmac,timingSafeEqual,randomUUID} from "node:crypto";
export const config={path:"/api/*"};
const J=(o,s=200,h={})=>new Response(JSON.stringify(o),{status:s,headers:{"content-type":"application/json","cache-control":"no-store",...h}});
const sign=v=>createHmac("sha256",process.env.SESSION_SECRET||"").update(v).digest("hex");
const eq=(a,b)=>{const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&timingSafeEqual(x,y)};
const USERS=["douae","mohammed"];
const whoIs=req=>{const c=(req.headers.get("cookie")||"").match(/(?:^|; )s=([a-z]+)\.([a-f0-9]+)/);return c&&USERS.includes(c[1])&&eq(sign(c[1]),c[2])?c[1]:null};
const PUSH=!!(process.env.VAPID_PUBLIC_KEY&&process.env.VAPID_PRIVATE_KEY);
if(PUSH)webpush.setVapidDetails("mailto:hello@example.com",process.env.VAPID_PUBLIC_KEY,process.env.VAPID_PRIVATE_KEY);
const clip=(s,n)=>String(s||"").trim().slice(0,n);
export default async(req,ctx)=>{
  const p=new URL(req.url).pathname.replace(/^\/api\//,""),db=getStore("us"),ph=getStore("photos");
  const get=async(k,d)=>(await db.get(k,{type:"json"}))??d;
  if(p==="login"&&req.method==="POST"){
    const rk="rl:"+(ctx.ip||"x"),now=Date.now();
    let r=await get(rk,{n:0,t:now});if(now-r.t>9e5)r={n:0,t:now};
    if(r.n>=5)return J({error:"Too many tries, come back in a bit 🌙"},429);
    const b=await req.json().catch(()=>({}));
    const ok=USERS.includes(b.who)&&process.env.APP_PASSCODE&&process.env.SESSION_SECRET&&eq(clip(b.pass,100),process.env.APP_PASSCODE.trim());
    if(!ok){r.n++;await db.setJSON(rk,r);return J({error:"Wrong name or passcode"},401)}
    await db.setJSON(rk,{n:0,t:now});
    return J({who:b.who},200,{"set-cookie":`s=${b.who}.${sign(b.who)}; Path=/; Max-Age=31536000; HttpOnly; Secure; SameSite=Lax`});
  }
  const me=whoIs(req);if(!me)return J({error:"login"},401);
  const addMsg=async m=>{const l=await get("messages",[]);l.push({from:me,ts:Date.now(),...m});await db.setJSON("messages",l.slice(-500));await notify(m)};
  const notify=async m=>{
    if(!PUSH)return;
    const to=me==="douae"?"mohammed":"douae",nm=me==="douae"?"Douae 🌸":"Mohammed 🌙",subs=await get("push",{}),list=subs[to]||[];
    if(!list.length)return;
    const body=m.kind==="heart"?"is thinking of you 💞":m.kind==="photo"?"sent you a photo 📷":clip(m.text,100);
    const payload=JSON.stringify({title:nm,body});let dirty=false;
    await Promise.all(list.map(async s=>{try{await webpush.sendNotification(s,payload)}catch(e){if(e.statusCode===404||e.statusCode===410){subs[to]=subs[to].filter(x=>x.endpoint!==s.endpoint);dirty=true}}}));
    if(dirty)await db.setJSON("push",subs);
  };
  const body=()=>req.json().catch(()=>({}));
  if(p==="me")return J({who:me});
  if(p==="vapid")return J({key:PUSH?process.env.VAPID_PUBLIC_KEY:""});
  if(p==="push"&&req.method==="POST"){const b=await body(),s=b.sub;
    if(!s||typeof s.endpoint!=="string"||!s.endpoint.startsWith("https://")||!s.keys)return J({error:"x"},400);
    const subs=await get("push",{}),l=(subs[me]||[]).filter(x=>x.endpoint!==s.endpoint);
    l.push({endpoint:s.endpoint,keys:{p256dh:clip(s.keys.p256dh,200),auth:clip(s.keys.auth,100)}});subs[me]=l.slice(-5);await db.setJSON("push",subs);return J({ok:1});}
  if(p==="state")return J({messages:await get("messages",[]),songs:await get("songs",[]),places:await get("places",{}),together:await get("together","")});
  if(req.method==="GET"&&p.startsWith("photo/")){
    const d=await ph.get(p.slice(6).replace(/[^a-f0-9-]/g,""),{type:"arrayBuffer"});
    return d?new Response(d,{headers:{"content-type":"image/jpeg","cache-control":"private, max-age=31536000, immutable"}}):J({error:"nf"},404);
  }
  if(req.method!=="POST")return J({error:"nf"},404);
  if(p==="msg"){const b=await body();
    if(b.kind==="heart")await addMsg({kind:"heart"});
    else if(clip(b.text,2000))await addMsg({text:clip(b.text,2000)});
    return J({ok:1});}
  if(p==="photo"){const d=await req.arrayBuffer();if(!d.byteLength||d.byteLength>5e6)return J({error:"size"},413);
    const id=randomUUID();await ph.set(id,d);await addMsg({kind:"photo",url:"/api/photo/"+id});return J({ok:1});}
  if(p==="song"){const b=await body(),t=clip(b.title,120);if(!t)return J({error:"x"},400);
    const l=await get("songs",[]);l.unshift({title:t,artist:clip(b.artist,120),from:me,ts:Date.now()});await db.setJSON("songs",l.slice(0,200));return J({ok:1});}
  if(p==="place"){const b=await body(),l=await get("places",{});
    l[me]={label:clip(b.label,100),ts:Date.now()};
    if(Number.isFinite(b.lat)&&Number.isFinite(b.lng)){l[me].lat=+b.lat.toFixed(3);l[me].lng=+b.lng.toFixed(3)}
    await db.setJSON("places",l);return J({ok:1});}
  if(p==="together"){const b=await body();if(/^\d{4}-\d{2}-\d{2}$/.test(b.date||""))await db.setJSON("together",b.date);return J({ok:1});}
  return J({error:"nf"},404);
};

# Douae & Mohammed 🌙🌸
Deploy: push this folder to GitHub, then Netlify > Add new site > Import from Git (or run `npx netlify deploy --prod`).
Site settings > Environment variables:
- APP_PASSCODE = 10-2026
- SESSION_SECRET = any long random text (30+ characters)
Then open the site on both phones and Add to Home Screen.

## Push notifications
Add two more environment variables: VAPID_PUBLIC_KEY and VAPID_PRIVATE_KEY (generate your own with `npx web-push generate-vapid-keys`).
iPhone: needs iOS 16.4+ and the site added to Home Screen first, then tap "Turn on notifications".
